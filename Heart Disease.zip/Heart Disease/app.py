from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__,static_url_path='/static')

# Load the machine learning model
model = pickle.load(open('Heart.pkl', 'rb'))


@app.route('/')
def home():
    return render_template('index.html')
@app.route('/predict', methods=['POST'])
def predict():
    # Get the user input
    prediction_class = ""
    prediction_message = ""
    Age = int(request.form.get("1"))
    Sex = str(request.form.get("2"))
    ChestPainType = str(request.form.get("3"))
    RestingBP = int(request.form.get("4"))
    Cholesterol = int(request.form.get("5"))
    FastingBS = int(request.form.get("6"))
    RestingECG = str(request.form.get("7"))
    MaxHR = int(request.form.get("8"))
    ExerciseAngina = str(request.form.get("9"))
    Oldpeak = float(request.form.get("10"))
    ST_Slope = str(request.form.get("11"))

    # Create a feature vector from the user input
    #test_input =[40, 'M', 'ATA', 140, 289, 0, 'Normal', 172, 'N', 0.0, 'Up']
    user_input = [Age, Sex, ChestPainType, RestingBP, Cholesterol, FastingBS, RestingECG, MaxHR, ExerciseAngina,
                  Oldpeak, ST_Slope]

    # Make a prediction using the loaded model
    prediction = model.predict(np.array(user_input).reshape(1, -1))
    print(prediction)

    if prediction[0] == 1:
        prediction_class = "red"
        prediction_message = "You are at risk of heart disease."
    else:
        prediction_class = "green"
        prediction_message = "You are not at risk of heart disease."

    return render_template("result.html", prediction_message=prediction_message, prediction_class=prediction_class,
                           user_input=user_input)


if __name__ == "__main__":
    app.run(debug=True, port=5112)